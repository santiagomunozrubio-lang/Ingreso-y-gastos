# CONTROL – Santi Muñoz

Proyecto Android para convertir la aplicación HTML proporcionada en un APK instalable en tabletas y teléfonos Android.

## Abrir y generar APK

1. Instalar Android Studio.
2. Abrir esta carpeta como proyecto: `CONTROL-Santi-Munoz-Android`.
3. Esperar a que Gradle sincronice y descargue las herramientas necesarias.
4. En Android Studio: **Build > Build App Bundle(s) / APK(s) > Build APK(s)**.
5. El APK de depuración quedará normalmente en:
   `app/build/outputs/apk/debug/app-debug.apk`
6. Copiar el APK a la tablet e instalarlo.

## Aplicación

- Nombre: CONTROL – Santi Muñoz
- Paquete: com.santimunoz.control
- Min Android: 6.0 (API 23)
- Target: Android 15 (API 35)
- Los datos de la aplicación se guardan en `localStorage` del WebView.
- La biblioteca XLSX continúa cargándose desde CDN, por lo que se requiere Internet para esa función.

## Nota

Este proyecto conserva la lógica y las pantallas del HTML entregado. No se ha cambiado la estructura funcional de la aplicación salvo el nombre visible de la app.
